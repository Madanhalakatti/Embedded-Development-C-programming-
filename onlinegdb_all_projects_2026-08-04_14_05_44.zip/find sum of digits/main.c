/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a = 1, b=2, c= 3, d=4;
     int *p1, *p2, *p3, *p4;
     int sum;
     p1 = &a;
     p2 = &b;
     p3 = &c;
     p4 = &d;
     sum = *p1 + *p2 + *p3 +*p4;
     printf("sum = %d\n", sum);
     return 0;
}