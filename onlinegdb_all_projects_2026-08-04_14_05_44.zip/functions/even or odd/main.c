/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number;
    printf("enter an integer");
    scanf("%d", &number);
    if (number%2==0){
        printf(" %d is an even integer \n", number);
    }
    else {
        printf("%d is an odd integer \n", number);
    }
    

    return 0;
}