/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void checkSpeed(int speed)
{
    if (speed < 30)
        printf("Low Speed");
    else if (speed < 70)
        printf("Medium Speed");
    else
        printf("High Speed");
}

int main()
{
    int speed;

    printf("Enter motor speed: ");
    scanf("%d", &speed);

    checkSpeed(speed);

    return 0;
}
