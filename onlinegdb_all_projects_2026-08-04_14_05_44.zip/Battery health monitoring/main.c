/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int countlowvoltage(float voltage[], int size)
{
    int i, count = 0;

    for(i = 0; i < size; i++)
    {
        if(voltage[i] < 11.0)
        {
            count++;
        }
    }

    return count;
}

int main()
{
    float voltage[5] = {12.5, 10.8, 11.2, 9.9, 10.5};
    int lowcount;

    lowcount = countlowvoltage(voltage, 5);

    printf("Number of readings below 11 V = %d\n", lowcount);

    return 0;
}