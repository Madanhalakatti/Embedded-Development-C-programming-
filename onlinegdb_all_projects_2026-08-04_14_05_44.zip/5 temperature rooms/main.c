/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int temp[5];
    int i, sum = 0;
    float avg;
    printf("Enter temperatures of 5 rooms:\n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &temp[i]);
        sum = sum + temp[i];
    }

    avg = sum / 5.0;
    printf("Average temperature = %.2f\n", avg);

    return 0;
}
