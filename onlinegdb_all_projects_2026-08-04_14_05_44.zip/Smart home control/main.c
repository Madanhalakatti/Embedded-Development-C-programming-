/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int choice;
    int lightStatus = 0; 
    int fanStatus = 0;

    while(1) {
        printf("\n=============================\n");
        printf("Current Status:\n");
        printf("Light: %s | Fan: %s\n", (lightStatus ? "ON" : "OFF"), (fanStatus ? "ON" : "OFF"));
        printf("=============================\n");
        printf("1. Turn Light ON\n");
        printf("2. Turn Light OFF\n");
        printf("3. Turn Fan ON\n");
        printf("4. Turn Fan OFF\n");
        printf("5. Exit Program\n");
        printf("Enter your choice (1-5): ");
        scanf("%d", &choice);

        switch(choice) {
            case 1:
                lightStatus = 1;
                printf("\n[Action] Light turned ON.\n");
                break;
            case 2:
                lightStatus = 0;
                printf("\n[Action] Light turned OFF.\n");
                break;
            case 3:
                fanStatus = 1;
                printf("\n[Action] Fan turned ON.\n");
                break;
            case 4:
                fanStatus = 0;
                printf("\n[Action] Fan turned OFF.\n");
                break;
            case 5:
                printf("\nExiting program. Goodbye!\n");
                exit(0);
            default:
                printf("\n[Error] Invalid choice! Please select between 1 and 5.\n");
        }
    }
    return 0;
}
