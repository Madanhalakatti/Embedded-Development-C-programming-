/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h> // Required for the sleep function

int main() {
    int level;

    printf("--- Water Tank Monitoring System ---\n");
    for (level = 0; level <= 100; level += 10) {
        printf("Tank Level: %d%%\n", level);

        if (level == 100) {
            printf("Status: Tank is FULL! Motor turning OFF.\n");
        } else {
            printf("Status: Filling... Pumping water into tank.\n");
        }


        sleep(1); 
    }

    printf("--- Monitoring Complete ---\n");
    return 0;
}
