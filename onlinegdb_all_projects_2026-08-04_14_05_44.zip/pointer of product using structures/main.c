/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Product
{
    int id;
    char name[20];
    float price;
};

int main()
{
    struct Product p = {101, "Laptop", 45000.50};
    struct Product *ptr;

    ptr = &p;

    printf("Product ID = %d\n", ptr->id);
    printf("Product Name = %s\n", ptr->name);
    printf("Price = %.2f\n", ptr->price);

    return 0;
}
