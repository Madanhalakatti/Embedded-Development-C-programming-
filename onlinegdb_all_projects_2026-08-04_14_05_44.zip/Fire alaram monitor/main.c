/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>

int main() {
    float current_temperature = 0.0;
    
    while (true) {
        

        current_temperature = 85.5; 
        
        if (current_temperature >= 80.0) {
            printf("Fire detected! Temperature is %.2f°C. Stopping monitoring.\n", current_temperature);
            break; 
        } else {
            printf("Monitoring... Current temperature: %.2f°C\n", current_temperature);
        }
    }
    
    return 0;
}
