/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void set_brightness(int *brightness)
{
    *brightness = 100; 
}

int main()
{
    int brightness = 50;

    printf("Before  Brightness = %d\n", brightness);

    set_brightness(&brightness);

    printf("After Brightness = %d\n", brightness);

    return 0;
}