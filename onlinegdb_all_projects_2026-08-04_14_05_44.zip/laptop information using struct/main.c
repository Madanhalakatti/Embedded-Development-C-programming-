/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Laptop
{
    int ram;
    char brand[20];
    float price;
};

int main()
{
    struct Laptop l = {16, "Dell", 55000.00};

    printf("RAM = %d GB\n", l.ram);
    printf("Brand = %s\n", l.brand);
    printf("Price = %.2f\n", l.price);

    return 0;
}