/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    float temp;
    for (int i = 1; i <= 10; i++) {
        printf("Enter temperature %d: ", i);
        scanf("%f", &temp);
        printf("Temperature %d is: %.2f\n\n", i, temp);
    }

    return 0;
}
