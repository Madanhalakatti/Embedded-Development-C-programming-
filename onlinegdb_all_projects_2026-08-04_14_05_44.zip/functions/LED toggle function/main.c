/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void toggleLED() {
    static int count = 0; 
    
    if (count < 5) {
        count++;
        printf("LED on/off\n", count);
    } else {
        printf("LED blink\n");
    }
}

int main() {

    for (int i = 0; i < 6; i++) {
        toggleLED();
    }
    
    return 0;
}