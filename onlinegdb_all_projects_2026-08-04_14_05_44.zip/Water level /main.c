/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int water_level = 0;
    int max_capacity = 100;

    printf("Starting water filling process...\n");

    while (1) {
    
        water_level += 10; 
        
        printf("Current water level: %d%%\n", water_level);
        if (water_level >= max_capacity) {
            printf("Tank reached 100%%! Stopping the filling process.\n");
            break;
        }
    }

    return 0;
}
