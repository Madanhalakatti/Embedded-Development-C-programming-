/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int room[3][4] = {
        {1,0,1,0},
        {0, 1, 1, 0},  
        {1, 1, 0, 1} 
    };

    int i, j;

    for(i = 0; i < 3; i++)
    {
        printf("Floor %d:\n", i + 1);

        for(j = 0; j < 4; j++)
        {
            if(room[i][j] == 1)
                printf("Room %d = ON\n", j + 1);
            else
                printf("Room %d = OFF\n", j + 1);
        }

        printf("\n");
    }

    return 0;
}