/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    float a=12.4 , b=3.1 , res;
    res = a+b;
    printf("a+b is %f\n", res);
    res=a-b;
    printf("a-b is %f\n", res);
    res=a*b;
    printf("a*b is %f\n", res);
    res=a/b;
    printf("a/b is %f\n", res);
    return 0;
}

