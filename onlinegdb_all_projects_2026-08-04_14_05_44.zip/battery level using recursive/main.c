/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void battery_discharge(int level)
{
    printf("Battery Level = %d%%\n", level);

    if (level == 0)
        return;

    battery_discharge(level - 10);
}

int main()
{
    battery_discharge(100);

    return 0;
}