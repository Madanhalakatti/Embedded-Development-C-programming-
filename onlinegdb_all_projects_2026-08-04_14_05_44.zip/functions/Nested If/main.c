/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int Attendance, cgpa;
printf("enter attendance");
scanf("%d", &Attendance);
printf("enter cgpa");
scanf("%d", &cgpa);
    if(Attendance>=75)
    {
        if (cgpa>=7)
        {
         printf("student can attend \n");
        }
        else{
            printf("student cannot attend \n");
          }
        
    }
    else {
        printf("student cannot attend \n");
    }
   


    return 0;
}
    


