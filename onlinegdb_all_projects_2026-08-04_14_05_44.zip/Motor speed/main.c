/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h> 

int main() {
    int target_rpm = 2000;
    int step = 100;

    for (int current_rpm = 0; current_rpm <= target_rpm; current_rpm += step) {
        printf("Motor Speed: %d RPM\n", current_rpm);
        usleep(500000); 
    }

    printf("Target speed of 2000 RPM reached!\n");

    return 0;
}
