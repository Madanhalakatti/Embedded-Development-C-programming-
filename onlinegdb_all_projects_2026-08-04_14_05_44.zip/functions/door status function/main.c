/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void doorStatus(int status)
{
    if (status == 1)
        printf("Door Open");
    else
        printf("Door Closed");
}

int main()
{
    int status;

    printf("Enter door status (1-Open, 0-Closed) ");
    scanf("%d", &status);

    return 0;
}
