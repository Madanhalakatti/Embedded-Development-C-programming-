/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[3] = {10, 20, 30,};
    int*ptr;
    printf("%p\n", a);
    printf ("%p\n", &a[0]);
    printf ("%p \n", &a[1]);
    return 0;
}