/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() 
{
    int a=3, b=6, sum, prod, rem;
    sum = a+b;
    printf("a+b is %d \n", sum);
    sum = a-b;
    printf("a-b is %d\n", sum);
    sum = a*b;
    printf("a*b is %d\n", sum);
    sum = a/b;
    printf("a/b is %d\n", sum);
    sum = a % b;
     printf("a % % b is %d\n", sum);
  if (prod > rem) {
      printf(",result: the product is greater than remainder.\n");
        }
        else if (prod < rem)
        {
            printf("result : the remainder is greater than product.\n");
        } 
        
        
        
}
