/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num = 5;
    int *ptr;
    int i, fact = 1;

    ptr = &num;

    for(i = 1; i <= *ptr; i++)
    {
        fact = fact * i;
    }

    printf("Factorial = %d\n", fact);

    return 0;
}