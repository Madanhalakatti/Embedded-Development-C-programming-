/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int device[5] = {1, 0, 1, 0, 1};
    char *name[5] = {"Light", "Fan", "TV", "AC", "Motor"};
    int i;

    for(i = 0; i < 5; i++)
    {
        printf("%s = %s\n", name[i],
               device[i] ? "ON" : "OFF");
    }

    return 0;
}