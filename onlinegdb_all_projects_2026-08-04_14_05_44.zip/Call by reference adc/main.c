/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void calibrate_adc(int *adc_value)
{
    int offset = 10;    
    *adc_value = *adc_value + offset;
}

int main()
{
    int adc_value = 100;

    printf("Before Calibration ADC Value = %d\n", adc_value);

    calibrate_adc(&adc_value);

    printf("After Calibration ADC Value = %d\n", adc_value);

    return 0;
}
