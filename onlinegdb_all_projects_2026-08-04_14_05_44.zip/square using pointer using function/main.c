/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/#include <stdio.h>
#include <stdio.h>

void square(int *num)
{
    int result;

    result = (*num) * (*num);

    printf("Square = %d\n", result);
}

int main()
{
    int n = 5;

    square(&n);

    return 0;
}