/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int choice;
    int isRunning = 0;

    do {
        
        printf("\n--- Machine Control Panel ---\n");
        printf("1. Start Machine\n");
        printf("2. Stop Machine\n");
        printf("3. Check Status\n");
        printf("4. Exit\n");
        printf("Enter your choice (1-4): ");
        scanf("%d", &choice);

    
        switch (choice) {
            case 1:
                if (isRunning == 0) {
                    isRunning = 1;
                    printf("Success: Machine started.\n");
                } else {
                    printf("Notice: Machine is already running.\n");
                }
                break;
            case 2:
                if (isRunning == 1) {
                    isRunning = 0;
                    printf("Success: Machine stopped.\n");
                } else {
                    printf("Notice: Machine is already stopped.\n");
                }
                break;
            case 3:
                if (isRunning == 1) {
                    printf("Status: Machine is currently RUNNING.\n");
                } else {
                    printf("Status: Machine is currently STOPPED.\n");
                }
                break;
            case 4:
                printf("Exiting program. Goodbye!\n");
                exit(0);
            default:
                printf("Error: Invalid input. Please enter 1, 2, 3, or 4.\n");
        }
    } while (1); 

    return 0;
}