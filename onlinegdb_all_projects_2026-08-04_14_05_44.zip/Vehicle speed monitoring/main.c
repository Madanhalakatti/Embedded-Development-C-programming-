/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int speeds[] = {45, 55, -1, 60, -1, 70, 35};
    int total_elements = sizeof(speeds) / sizeof(speeds[0]);

    printf("Processing vehicle speeds:\n");

    for (int i = 0; i < total_elements; i++) {
        if (speeds[i] == -1) {
            continue; 
        }

    
        printf("Vehicle %d speed: %d mph\n", i + 1, speeds[i]);
    }

    return 0;
}
