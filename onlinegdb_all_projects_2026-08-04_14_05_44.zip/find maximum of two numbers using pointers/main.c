/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a = 15, b= 25;
    int *p1, *p2;
    p1 =&a;
    p2 = &b;
    if (*p1> *p2)
    printf("maximum = %d\n", *p1);
     else
    printf("maximum = %d\n", *p2);
    return 0;
}
