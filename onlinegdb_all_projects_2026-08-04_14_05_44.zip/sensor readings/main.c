/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int averageTemp(int s1, int s2, int s3, int s4, int s5)
{
    return (s1 + s2 + s3 + s4 + s5) / 5;
}

int main()
{
    int s1, s2, s3, s4, s5;

    printf("Enter 5 sensor readings ");
    scanf("%d %d %d %d %d", &s1, &s2, &s3, &s4, &s5);

    printf("Avg Temp = %d", averageTemp(s1, s2, s3, s4, s5));

    return 0;
}