/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int totalPulse = 0;   // Global variable

void sensor1()
{
    totalPulse += 10;
}

void sensor2()
{
    totalPulse += 15;
}

void sensor3()
{
    totalPulse += 20;
}

int main()
{
    sensor1();
    sensor2();
    sensor3();

    printf("Total Pulse Count = %d", totalPulse);

    return 0;
}
