/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num = 30;
    int *ptr;
    ptr = &num;
    printf("value of variable =%d\n", num);
    printf("Address of variable = %p\n", (void *)&num);
    printf("value stored in pointer =%p\n",(void *)ptr);
    printf("value pointed by pointer =%d\n", *ptr);
    return 0;
}