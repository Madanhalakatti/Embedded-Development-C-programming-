/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    unsigned char led = 0; 
    
    printf("Initial LED state: %d\n\n", led);
    for (int i = 0; i < 5; i++) {
        led ^= 1; 
        
        printf("Toggle %d -> LED state: %d (%s)\n", i + 1, led, led ? "ON" : "OFF");
    }

    return 0;
}
