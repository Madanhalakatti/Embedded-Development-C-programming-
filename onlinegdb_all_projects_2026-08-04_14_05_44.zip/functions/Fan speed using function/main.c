/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int fanSpeed(int temperature);

int main()
{
    int temperature, speed;

    printf("Enter temperature: ");
    scanf("%d", &temperature);

    speed = fanSpeed(temperature);

    printf("Fan Speed = %d\n", speed);

    return 0;
}


int fanSpeed(int temperature)
{
    if (temperature < 30)
    {
        return 1;
    }
    else if (temperature <= 40)
    {
        return 2;
    }
    else if (temperature > 40)
    {
        return 3;
    }
}
