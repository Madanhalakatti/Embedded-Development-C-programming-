/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

static int motorSpeed = 100; 

void increaseSpeed()
{
    motorSpeed += 10;
}

void displaySpeed()
{
    printf("Motor Speed = %d RPM\n", motorSpeed);
}

int main()
{
    displaySpeed();

    increaseSpeed();
    displaySpeed();

    increaseSpeed();
    displaySpeed();

    return 0;
}