/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

int main()
{
    struct Node *head;

    head = (struct Node *)malloc(sizeof(struct Node));

    head->data = 10;
    head->next = NULL;

    printf("Data = %d\n", head->data);
    printf("Next = %p\n", (void *)head->next);

    free(head);

    return 0;
}