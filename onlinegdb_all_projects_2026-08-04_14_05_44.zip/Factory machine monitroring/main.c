/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int temp[3][5];
    int i, j;

    printf("Enter temperatures for 3 machines and 5 hours \n");

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 5; j++)
        {
            scanf("%d", &temp[i][j]);
        }
    }

    printf("Temperature Values\n");

    for(i = 0; i < 3; i++)
    {
        printf("Machine %d: ", i + 1);

        for(j = 0; j < 5; j++)
        {
            printf("%d ", temp[i][j]);
        }

        printf("\n");
    }

    return 0;
}