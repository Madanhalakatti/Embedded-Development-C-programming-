/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main() {
    char correct_password[] = "secret1234"; 
    char user_input[50];
    int authenticated = 0;
    for (int attempts = 1; attempts <= 3; attempts++) {
        printf("Enter password (Attempt %d of 3): ", attempts);
        scanf("%s", user_input);
        if (strcmp(user_input, correct_password) == 0) {
            printf("Access granted!\n");
            authenticated = 1; 
            break;             
        } else {
            printf("Incorrect password.\n\n");
        }
    }
    if (!authenticated) {
        printf("Access denied. You have used all 3 attempts.\n");
    }

    return 0;
}
