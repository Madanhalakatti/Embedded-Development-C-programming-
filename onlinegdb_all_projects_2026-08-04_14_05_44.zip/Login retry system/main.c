/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main() {
    char password[20];
    int attempts = 0;
    const char correct_password[] = "secret123";

login_screen:
    printf("Enter password: ");
    scanf("%19s", password);

    if (strcmp(password, correct_password) == 0) {
        printf("\nLogin successful! Welcome aboard.\n");
        return 0; 
    } else {
        attempts++;
        printf("Incorrect password. Attempt %d of 3.\n\n", attempts);
        
        if (attempts < 3) {
            goto login_screen;
        } else {
            printf("Access denied. Too many incorrect attempts.\n");
        }
    }

    return 0;
}
