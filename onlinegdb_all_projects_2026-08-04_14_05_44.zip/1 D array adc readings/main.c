/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int adc[10];
    int i;
    printf("Enter 10 ADC readings \n");
    for(i = 0; i < 10; i++)
    {
        scanf("%d", &adc[i]);
    }
    printf("ADC Readings are \n");
    for(i = 0; i < 10; i++)
    {
        printf("ADC[%d] = %d\n", i, adc[i]);
    }

    return 0;
}