/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int getMaxAdc(int adc1, int adc2, int adc3) {
    int max = adc1;
    
    if (adc2 > max) {
        max = adc2;
    }
    if (adc3 > max) {
        max = adc3;
    }
    
    return max;
}

int main() {
    int adc1 = 40;
    int adc2 = 70;
    int adc3 = 90;

    int highestValue = getMaxAdc(adc1, adc2, adc3);

    printf("The highestValue: %d\n", highestValue);

    return 0;
}