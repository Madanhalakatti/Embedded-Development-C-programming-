/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void swap(int *temp1, int *temp2)
{
    int temp;

    temp = *temp1;
    *temp1 = *temp2;
    *temp2 = temp;
}

int main()
{
    int temp1 = 30;
    int temp2 = 40;

    printf("Before Swap\n");
    printf("Temp1 = %d\n", temp1);
    printf("Temp2 = %d\n", temp2);

    swap(&temp1, &temp2);

    printf("\nAfter Swap\n");
    printf("Temp1 = %d\n", temp1);
    printf("Temp2 = %d\n", temp2);

    return 0;
}
