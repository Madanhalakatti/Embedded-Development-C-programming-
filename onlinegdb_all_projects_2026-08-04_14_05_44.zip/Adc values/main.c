/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/#include<stdio.h>

#include<stdio.h>
int main()
{
    int adc[5] = {10, 20, 30, 40, 50};

    printf("adc values are:\n");

    for (int i = 0; i < 5; i++)
    {
        printf("adc[%d] = %d\n", i, adc[i]);
    }

    return 0;
}
