/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[4] = {10, 20, 30, 40};
    int i, sum = 0;

    for(i = 0; i < 4; i++)
    {
        sum = sum + a[i];
    }

    printf("Sum = %d\n", sum);

    return 0;
}