/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int readings[] = {15, -3, 22, -8, 0, 45, -12, 30};
    int size = sizeof(readings) / sizeof(readings[0]);

    printf("Valid readings:\n");

    for (int i = 0; i < size; i++) {
        if (readings[i] < 0) {
            continue; 
        }
        

        printf("%d\n", readings[i]);
    }

    return 0;
}