/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void highestTemp(int temp)
{
    static int maxTemp = 0;

    if (temp > maxTemp)
        maxTemp = temp;

    printf("Highest Temperature = %d\n", maxTemp);
}

int main()
{
    highestTemp(30);
    highestTemp(45);
    highestTemp(40);
    highestTemp(50);

    return 0;
}