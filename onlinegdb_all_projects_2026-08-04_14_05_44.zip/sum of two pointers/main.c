/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a = 10, b= 20;
    int *p1 , *p2;
    int sum;
    p1 = &a;
    p2 = &b;
    sum = *p1 + *p2;
    printf("a =%d\n", a);
    printf("b = %d\n", b);
    printf("sum = %d\n", sum);
    return 0;
}
