/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[6] = {10, 20, 10, 30, 20, 10};
    int i, j, count;

    for(i = 0; i < 6; i++)
    {
        count = 1;

        for(j = 0; j < i; j++)
        {
            if(a[i] == a[j])
                break;
        }

        if(j == i)
        {
            for(j = i + 1; j < 6; j++)
            {
                if(a[i] == a[j])
                    count++;
            }

            printf("%d - %d\n", a[i], count);
        }
    }

    return 0;
}