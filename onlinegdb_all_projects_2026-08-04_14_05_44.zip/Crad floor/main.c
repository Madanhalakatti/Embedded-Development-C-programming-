/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int isCardValid = 1;         // 1 = Valid, 0 = Invalid
    int hasFloorPermission = 1;  // 1 = Permitted, 0 = Denied
    int currentFloor = 0;
    int targetFloor;

    printf("Enter the target floor (0-10): ");
    scanf("%d", &targetFloor);

    // Outer If: Check if the access card itself is valid
    if (isCardValid == 1) {
        
        // Nested If: Check if the user has permission for the specific floor
        if (hasFloorPermission == 1) {
            
            // Check if the target floor is within building limits (0 to 10)
            if (targetFloor >= 0 && targetFloor <= 10) {
                printf("Access Granted! Elevator is moving from floor %d to floor %d.\n", currentFloor, targetFloor);
                currentFloor = targetFloor; // Update elevator position
            } else {
                printf("Access Denied: Invalid floor number.\n");
            }
            
        } else {
            printf("Access Denied: You do not have permission for this specific floor.\n");
        }
        
    } else {
        printf("Access Denied: Invalid or expired access card.\n");
    }

    return 0;
}