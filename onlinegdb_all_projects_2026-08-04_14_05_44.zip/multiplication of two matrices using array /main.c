/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a[3] [3]={
        {1,2,3},
        {4, 5, 6},
        {7,8,9}
    };
    int b [3] [3]={
        {1, 2, 3},
        {4,5,6},
        {7,8,9}
    };
    int c [3] [3]={0};
    int i , j, k;
    for (i=0; i<3; i++)
    {
        for (j=0; j<3; j++)
        {
            for (k=0; k<3; k++)
            {
                c[i][j]+= a[i][k]*b[k][j];
            }
        }
    }
    printf("matrix multiplication\n");
    for (i=0; i<3; i++)
    {
        for (j=0; j<3; j++)
        {
            printf("%d", c[i][j]);
        }
        printf("\n");
    }
        return 0;
    }
