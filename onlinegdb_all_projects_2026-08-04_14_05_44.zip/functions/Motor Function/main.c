/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void motorOn() {
    printf("Motor is ON\n");
}

void motorOff() {
    printf("Motor is OFF\n");
}

int main() {
    int condition;

    printf("Enter condition (1 = ON, 0 = OFF): ");
    scanf("%d", &condition);

    if (condition == 1) {
        motorOn();
    } else {
        motorOff();
    }

    return 0;
}