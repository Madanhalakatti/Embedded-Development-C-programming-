/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n, i, sum = 0;
    int sensor[100];
    float avg;

    printf("Enter number of readings: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        scanf("%d", &sensor[i]);
        sum += sensor[i];
    }

    avg = (float)sum / n;

    printf("Average = %.2f\n", avg);

    return 0;
}