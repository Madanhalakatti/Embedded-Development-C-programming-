/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int cardValid = 1;     
    int passwordCorrect = 1;


    if (cardValid == 1) {
        if (passwordCorrect == 1) {
            printf("Access Granted. The door opens.\n");
        } else {
            printf("Error: Incorrect password.\n");
        }
    } else {
        printf("Error: Invalid RFID card.\n");
    }

    return 0;
}
