/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int temp;

// 1. No Arguments, No Return Value
void readTemp()
{
    printf("Enter Temperature: ");
    scanf("%d", &temp);
}

// 2. Arguments, No Return Value
void displayTemp(int t)
{
    printf("Temperature = %d\n", t);
}

// 3. No Arguments, Return Value
int getTemp()
{
    return temp;
}

// 4. Arguments, Return Value
int checkHighTemp(int t)
{
    if (t > 40)
        return 1;
    else
        return 0;
}

int main()
{
    int value;

    readTemp();              // Type 1
    value = getTemp();       // Type 3
    displayTemp(value);      // Type 2

    if (checkHighTemp(value)) // Type 4
        printf("High Temperature Alert!");
    else
        printf("Temperature Normal");

    return 0;
}
