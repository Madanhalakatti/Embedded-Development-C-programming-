/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int led[5] = {1, 0, 1, 0, 1};
    int i;

    for(i = 0; i < 5; i++)
    {
        if(led[i] == 1)
            printf("LED %d = ON\n", i + 1);
        else
            printf("LED %d = OFF\n", i + 1);
    }

    return 0;
}