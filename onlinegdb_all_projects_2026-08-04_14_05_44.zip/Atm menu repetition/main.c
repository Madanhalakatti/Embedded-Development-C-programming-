/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int choice;
    float balance = 1000.00; 
    float amount;

    do {
        printf("\n===== BANKING SYSTEM MENU =====\n");
        printf("1. Check Balance\n");
        printf("2. Deposit Money\n");
        printf("3. Withdraw Money\n");
        printf("4. Exit\n");
        printf("===============================\n");
        printf("Enter your choice (1-4): ");
        scanf("%d", &choice);

        
        switch (choice) {
            case 1:
                printf("\nYour current balance is: $%.2f\n", balance);
                break;

            case 2:
                printf("\nEnter the amount to deposit: $");
                scanf("%f", &amount);
                if (amount > 0) {
                    balance += amount; 
                    printf("$%.2f deposited successfully!\n", amount);
                } else {
                    printf("Invalid deposit amount! Amount must be greater than 0.\n");
                }
                break;

            case 3:
                printf("\nEnter the amount to withdraw: $");
                scanf("%f", &amount);
                if (amount > balance) {
                    printf("Insufficient balance! Transaction failed.\n");
                } else if (amount <= 0) {
                    printf("Invalid withdrawal amount! Amount must be greater than 0.\n");
                } else {
                    balance -= amount; 
                    printf("$%.2f withdrawn successfully!\n", amount);
                }
                break;

            case 4:
                printf("\nThank you for using our banking system. Goodbye!\n");
                break;

            default:
                printf("\nInvalid choice! Please select an option between 1 and 4.\n");
        }
    } while (choice != 4); 

    return 0;
}