/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <reg51.h> 

sbit SW1 = P1^0;      
sbit SW2 = P1^1;     
sbit LED = P2^0;      
sbit MOTOR =p2^1;

void delay(unsigned int time) {
    unsigned int i, j;
    for(i = 0; i < time; i++) {
        for(j = 0; j < 1275; j++); 
    }
}

void main() {
    SW1 = 1; 
    SW2 = 1; 
    
    LED = 0;
    MOTOR = 0;

    while(1) { 
        
        if (SW1 == 0) {       
            LED = 1;          
        } else {
            LED = 0;         
        }


        if (SW2 == 0) {
            MOTOR = 1;      
        } else {
            MOTOR = 0;      
        }
        
        delay(10); 
    }
}
