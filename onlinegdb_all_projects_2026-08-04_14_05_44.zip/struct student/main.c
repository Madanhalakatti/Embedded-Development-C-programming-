/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct Student
{ 
    int rollno;
    char name[20];
    float marks;
};

int main()
{
    struct Student s ={101, "john", 86.4};
    printf("roll number=%d\n", s.rollno);
    printf("Name = %s\n", s.name);
    printf("Marks=%.1f\n", s.marks);

    return 0;
}