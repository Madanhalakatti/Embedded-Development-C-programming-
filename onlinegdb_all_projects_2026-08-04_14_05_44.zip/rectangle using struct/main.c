/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Rectangle
{
    int length;
    int width;
};

int main()
{
    struct Rectangle r;
    int area, perimeter;

    r.length = 10;
    r.width = 5;

    area = r.length * r.width;
    perimeter = 2 * (r.length + r.width);

    printf("Length = %d\n", r.length);
    printf("Width = %d\n", r.width);
    printf("Area = %d\n", area);
    printf("Perimeter = %d\n", perimeter);

    return 0;
}