/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int year;
    printf("enter the year\n");
    scanf("%d", &year);
    if ((year % 4 == 0 && year %100 !=0) || (year % 500 == 0))
    {
        printf("enter the year is leap year\n", year);
    }
        else{
            printf("the year is not leap year\n", year);
            
        }
        return 0;
    }

