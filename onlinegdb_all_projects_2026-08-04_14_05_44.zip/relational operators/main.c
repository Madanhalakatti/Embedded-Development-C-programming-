/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a=15, b=20;
    if(a<b)
    printf("Battery level is low b\n");
    else
    printf("Battery level is Ok b\n");
    if (a>b)
    printf("Battery level is low b\n");
    else
    printf("battery level is Ok b\n");
    return 0;
    
}