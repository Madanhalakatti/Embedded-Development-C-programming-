/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int choice;
    int carCount = 0;
    const int MAX_CAPACITY = 50; 


    while (1) {
        printf("\n=== Car Parking System ===\n");
        printf("1. Car Entry\n");
        printf("2. Car Exit\n");
        printf("3. Display Current Car Count\n");
        printf("4. Exit\n");
        printf("Enter your choice (1-4): ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                if (carCount < MAX_CAPACITY) {
                    carCount++;
                    printf("Success: A car has entered. Total cars: %d\n", carCount);
                } else {
                    printf("Error: Parking is full! Max capacity is %d.\n", MAX_CAPACITY);
                }
                break;

            case 2:
                if (carCount > 0) {
                    carCount--;
                printf("Success: A car has exited. Total cars: %d\n", carCount);
                } else {
                    printf("Error: Parking is empty. No cars to exit.\n", carCount);
                }
                break;

            case 3:
                printf("Info: Current number of cars in the parking lot: %d\n", carCount);
                break;

            case 4:
                printf("Exiting system. Goodbye!\n");
                exit(0); 

            default:
                printf("Invalid input! Please enter a number between 1 and 4.\n");
        }
    }

    return 0;
}
