/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    int soil_moisture = 20;
    int water_available = 1;
    if (soil_moisture >= 20 && water_available == 1) {
        printf("Conditions met. PUMP ON.\n");
    } else {
        printf("Conditions not met. PUMP OFF.\n");
    }
    if (soil_moisture <= 20 && water_available == 1) {
        printf("Conditions met. PUMP OFF.\n");
    } else {
        printf("Conditions not met. PUMP ON.\n");
    }

    return 0;
}
