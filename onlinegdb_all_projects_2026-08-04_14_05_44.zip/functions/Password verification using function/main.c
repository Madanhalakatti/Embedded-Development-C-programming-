/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int checkPassword(int enteredPassword);

int main()
{
    int enteredPassword;
    int result;

    printf("Enter Password: ");
    scanf("%d", &enteredPassword);

    result = checkPassword(enteredPassword);

    if (result == 1)
        printf("Password Correct\n");
    else
        printf("Password Incorrect\n");

    return 0;
}

int checkPassword(int enteredPassword)
{
    int correctPassword = 8055;

    if (enteredPassword == correctPassword)
        return 1;
    else
        return 0;
}