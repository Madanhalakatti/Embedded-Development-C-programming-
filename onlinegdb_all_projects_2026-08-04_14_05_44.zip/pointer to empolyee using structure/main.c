/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Empolyee
{
    int id;
    char name[30];
};

void display(struct Empolyee emp)
{
    printf("Empolyee ID = %d\n", emp.id);
    printf("Empolyee Name = %s\n", emp.name);
}

int main()
{
    struct Empolyee emp1;

    printf("Enter Empolyee ID: ");
    scanf("%d", &emp1.id);

    printf("Enter Empolyee Name: ");
    scanf("%s", emp1.name);

    display(emp1);

    return 0;
}