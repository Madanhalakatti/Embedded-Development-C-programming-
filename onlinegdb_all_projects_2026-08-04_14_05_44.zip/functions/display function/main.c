/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int sensorValue;

void readSensor()
{
    printf("Enter sensor value: ");
    scanf("%d", &sensorValue);
}

void displayData()
{
    printf("Sensor Value = %d", sensorValue);
}

int main()
{
    readSensor();
    displayData();

    return 0;
}
