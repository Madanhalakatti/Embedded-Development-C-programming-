#include<stdio.h>
int number;
int main()
{
    
}