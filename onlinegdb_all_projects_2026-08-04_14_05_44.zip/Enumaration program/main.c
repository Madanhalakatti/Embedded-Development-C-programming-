/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>

enum Days
{
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};

int main()
{
    printf("Monday = %d\n", Monday);
    printf("Tuesday = %d\n", Tuesday);
    printf("Wednesday = %d\n", Wednesday);
    printf("Thursday = %d\n", Thursday);
    printf("Friday = %d\n", Friday);
    printf("Saturday = %d\n", Saturday);
    printf("Sunday = %d\n", Sunday);

    return 0;
}