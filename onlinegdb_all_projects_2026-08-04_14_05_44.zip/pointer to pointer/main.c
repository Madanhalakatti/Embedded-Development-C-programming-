/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/#include <stdio.h>
#include<stdio.h>
int main()
{
    int num = 10;
    int *ptr;
    int **qptr;

    ptr = &num;
    qptr = &ptr;

    printf("Value of num      = %d\n", num);
    printf("Address of num    = %p\n", &num);

    printf("Value of ptr      = %p\n", ptr);
    printf("Address of ptr    = %p\n", &ptr);

    printf("Value of pptr     = %p\n", qptr);
    printf("Address of pptr   = %p\n", &qptr);

    printf("Value using ptr   = %d\n", *ptr);
    printf("Value using pptr  = %d\n", **qptr);

    return 0;
}
