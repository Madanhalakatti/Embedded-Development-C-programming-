/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Car
{
    int carNo;
    char brand[20];
    float mileage;
};

int main()
{
    struct Car c;

    printf("Enter Car Number: ");
    scanf("%d", &c.carNo);

    printf("Enter Brand: ");
    scanf("%s", c.brand);

    printf("Enter Mileage: ");
    scanf("%f", &c.mileage);
    printf("Car Number = %d\n", c.carNo);
    printf("Brand = %s\n", c.brand);
    printf("Mileage = %.2f\n", c.mileage);

    return 0;
}