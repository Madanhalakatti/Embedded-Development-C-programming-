/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main() {
    int enteredPin;
    const int CORRECT_PIN = 1234;
    try_again:

    printf("Enter your 4-digit PIN: ");
    scanf("%d", &enteredPin);
    if (enteredPin != CORRECT_PIN) {
        printf("Incorrect PIN. Please try again.\n\n");
        goto try_again; 
    }

    printf("PIN accepted! Access granted.\n");

    return 0;
}