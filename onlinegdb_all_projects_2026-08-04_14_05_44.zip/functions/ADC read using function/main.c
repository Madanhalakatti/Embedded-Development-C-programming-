/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int ADC_Read();

int main()
{
    int adcValue;

    adcValue = ADC_Read();

    printf("ADC Value = %d\n", adcValue);

    return 0;
}
int ADC_Read()
{
    int adc = 123;  
    return adc;
}
