/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {

    int product_status[] = {0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1};
    int total_products = 20;

    for (int i = 0; i < total_products; i++) {

        if (product_status[i] == 1) {
            printf("Product %d: Defective! Skipping...\n", i + 1);
            continue; 
        }

        printf("Product %d: Passed inspection. Ready for packaging.\n", i + 1);
    }

    printf("\nAll 20 products have been inspected.\n");
    return 0;
}
