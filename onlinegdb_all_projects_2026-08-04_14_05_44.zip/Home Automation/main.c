/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{

    int motion_detected = 1; 
    int night_time = 1;      
    
    if (motion_detected == 1 && night_time == 1) {
        printf("Light turned ON.\n");
    } else {
        printf("Light turned OFF.\n");
    }

    return 0;
}

