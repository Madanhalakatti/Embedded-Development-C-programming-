/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char uart[20];
    int i;

    printf("Enter characters \n");

    for(i = 0; i < 20; i++)
    {
        scanf("%c", &uart[i]);
    }

    uart[20] = '\0'; 

    printf( "%s\n", uart);

    return 0;
}
