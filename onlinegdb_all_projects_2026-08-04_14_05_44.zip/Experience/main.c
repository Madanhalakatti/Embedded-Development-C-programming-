/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() 
{
int experience, rating;
printf("enter experience");
scanf("%d", &experience);
printf("enter rating");
scanf("%d", &rating);
    if(experience>=3)
    {
        if (rating>=8)
        {
         printf("bonus is eligible \n");
        }
        else{
            printf("bonus is not eligible \n");
          }
        
    }
    else{
        printf("bonus is not eligible\n");
    }


    return 0;
}
