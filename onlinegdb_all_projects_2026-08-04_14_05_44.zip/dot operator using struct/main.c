/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

struct Employee
{
    int id;
    char name[20];
    float salary;
};

int main()
{
    struct Employee emp;

    emp.id = 101;
    strcpy(emp.name, "marlon");
    emp.salary = 25000.50;

    printf("Employee ID = %d\n", emp.id);
    printf("Employee Name = %s\n", emp.name);
    printf("Salary = %.2f\n", emp.salary);

    return 0;
}