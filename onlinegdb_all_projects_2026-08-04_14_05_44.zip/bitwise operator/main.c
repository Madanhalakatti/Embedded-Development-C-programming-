/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    unsigned char portb = 0xff; 
    
    printf("Original portb: %09d\n", portb);
    portb &= ~(1 << 0); 

    printf("Modified portb: %07d\n", portb); 

    return 0;
}

