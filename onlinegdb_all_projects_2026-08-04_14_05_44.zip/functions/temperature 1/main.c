/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(void) {
float read_temperature(void);

    float current_temp = read_temperature();

    printf(" temperature recorded is: %.2f°C\n", current_temp);
    
}

float read_temperature(void) {
    float temp;
    printf("Enter the current temperature: ");
    scanf("%f", &temp);
    return temp;
}
