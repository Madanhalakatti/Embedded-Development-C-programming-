/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

static int tankLevel;  

void fillTank()
{
    tankLevel += 10; 
}

void displayLevel()
{
    printf("Tank Level = %d liters\n", tankLevel);
}

int main()
{
    displayLevel();

    fillTank();
    displayLevel();

    fillTank();
    displayLevel();

    fillTank();
    displayLevel();

    return 0;
}

