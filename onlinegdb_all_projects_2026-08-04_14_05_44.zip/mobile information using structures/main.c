/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Mobile
{
    char brand[20];
    char model[20];
    float price;
};

int main()
{
    struct Mobile m = {"Apple", "17 pro max", 170000.00};

    printf("Brand = %s\n", m.brand);
    printf("Model = %s\n", m.model);
    printf("Price = %.2f\n", m.price);

    return 0;
}