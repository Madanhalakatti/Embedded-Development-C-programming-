/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void checkDoorStatus(int status);

int main()
{
    int status;

    printf("Enter door status (open =1 ,  Closed=0): ");
    scanf("%d", &status);

    checkDoorStatus(status);

    return 0;
}

void checkDoorStatus(int status)
{
    if (status == 1)
    {
        printf("Door Open\n");
    }
    else
    {
        printf("Door Closed\n");
    }
}
