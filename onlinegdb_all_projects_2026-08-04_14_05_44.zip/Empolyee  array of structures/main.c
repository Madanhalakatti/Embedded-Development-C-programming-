/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Employee
{
    int id;
    char name[20];
    float salary;
};

int main()
{
    struct Employee emp[5];
    

    for(int i = 0; i < 5; i++)
    {
        printf("Enter ID, Name and Salary of Employee %d: ", i + 1);
        scanf("%d %s %f", &emp[i].id, emp[i].name, &emp[i].salary);
    }

    printf("Employee Details\n");

    for(int i = 0; i < 5; i++)
    {
        printf("ID = %d\n", emp[i].id);
        printf("Name = %s\n", emp[i].name);
        printf("Salary = %.2f\n", emp[i].salary);
        printf("\n");
    }

    return 0;
}