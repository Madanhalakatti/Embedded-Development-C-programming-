/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct LibraryBook
{
    int bookId;
    char title[30];
    char author[30];
    float price;
};

int main()
{
    struct LibraryBook b;

    printf("Enter Book ID: ");
    scanf("%d", &b.bookId);

    printf("Enter Book Title: ");
    scanf("%s", b.title);

    printf("Enter Author Name: ");
    scanf("%s", b.author);

    printf("Enter Price: ");
    scanf("%f", &b.price);

    printf("book details are \n");
    printf("Book ID     : %d\n", b.bookId);
    printf("Book Title  : %s\n", b.title);
    printf("Author Name : %s\n", b.author);
    printf("Price       : %.2f\n", b.price);

    return 0;
}