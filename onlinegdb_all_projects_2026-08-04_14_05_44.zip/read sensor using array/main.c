/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int sensor[10];
    int i, count = 0;
    printf("Enter 10 sensor values\n");
    for(i = 0; i < 10; i++)
    {
        scanf("%d", &sensor[i]);
    }
    for(i = 0; i < 10; i++)
    {
        if(sensor[i] > 500)
        {
            count++;
        }
    }
    printf("Number of readings greater than 500 = %d\n", count);

    return 0;
}