/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int level[10];
    int i, min;
    printf("Enter 10 water level readings:\n");
    for(i = 0; i < 10; i++)
    {
        scanf("%d", &level[i]);
    }
    min = level[0];

    for(i = 1; i < 10; i++)
    {
        if(level[i] < min)
        {
            min = level[i];
        }
    }
    printf("Minimum water level = %d\n", min);

    return 0;
}