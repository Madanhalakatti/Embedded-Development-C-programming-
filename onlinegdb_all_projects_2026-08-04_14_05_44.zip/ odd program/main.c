/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int num;

    printf("Enter an integer: ");
    scanf("%d", &num);

    if (num % 2 != 0) {
        printf("%d is odd. Multiplying by 2...\n", num);
        num = num * 2;
        printf("New value: %d\n", num);
    } else {
        printf("%d is even. No need to multiply.\n", num);
    }

    return 0;
}
