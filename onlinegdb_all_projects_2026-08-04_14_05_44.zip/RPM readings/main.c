/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int rpm[10];
    int i, highest;

    printf("Enter RPM values for 10 seconds\n");
    for(i = 0; i < 10; i++)
    {
        scanf("%d", &rpm[i]);
    }
    highest = rpm[0];
    for(i = 1; i < 10; i++)
    {
        if(rpm[i] > highest)
        {
            highest = rpm[i];
        }
    }
    printf("Highest RPM = %d\n", highest);

    return 0;
}