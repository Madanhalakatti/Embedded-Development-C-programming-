/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int temp[5] = {25, 27, 26, 28, 24};

    printf("Room temperatures are:\n");

    for (int i = 0; i < 5; i++)
    {
        printf("Room %d = %d°C\n", i + 1, temp[i]);
    }

    return 0;
}