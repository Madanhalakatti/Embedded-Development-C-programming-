/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>

int main() {
    int battery = 100;

    printf("Starting battery discharge simulation...\n");
    while (battery >= 0) {
        printf("Battery: %d%%\n", battery);
        
        usleep(100000); 
        
        battery--;
    }

    printf("Battery depleted. Device shutting down.\n");
    return 0;
}