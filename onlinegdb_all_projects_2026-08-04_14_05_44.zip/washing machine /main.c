/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int choice;

    printf("====================================\n");
    printf("    APPLIANCE WASH MODE SELECTOR    \n");
    printf("====================================\n");
    printf("1. Quick Wash\n");
    printf("2. Normal Wash\n");
    printf("3. Heavy Wash\n");
    printf("4. Rinse Only\n");
    printf("5. Exit\n");
    printf("------------------------------------\n");
    printf("Enter your choice (1-5): ");

    scanf("%d", &choice);
    printf("\n");
    switch (choice) {
        case 1:
            printf("Selected: [QUICK WASH]\n");
            printf(">> Duration: 15 minutes.\n");
            printf(">> Status: Ideal for lightly soiled everyday clothes.\n");
            break;
            
        case 2:
            printf("Selected: [NORMAL WASH]\n");
            printf(">> Duration: 60 minutes.\n");
            printf(">> Status: Standard cycle for regular cottons and mixed loads.\n");
            break;
            
        case 3:
            printf("Selected: [HEAVY WASH]\n");
            printf(">> Duration: 90 minutes.\n");
            printf(">> Status: High intensity cleaning for tough stains and heavy fabrics.\n");
            break;
            
        case 4:
            printf("Selected: [RINSE ONLY]\n");
            printf(">> Duration: 20 minutes.\n");
            printf(">> Status: Rinsing clothes with clean water and spinning out moisture.\n");
            break;
            
        case 5:
            printf("Shutting down the appliance. Goodbye!\n");
            break;
            
        default:
            printf("Error: Invalid Mode Selected! Please choice an option between 1 and 5.\n");
            break;
    }

    printf("====================================\n");
    return 0;
}
