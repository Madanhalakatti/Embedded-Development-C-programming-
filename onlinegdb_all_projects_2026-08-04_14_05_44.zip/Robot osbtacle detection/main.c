/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>
int check_obstacle_distance() {
    int simulated_distances[] = {100, 80, 50, 30, 10, 0};
    static int index = 0;
    
    int current_distance = simulated_distances[index];
    if (index < 5) {
        index++;
    }
    return current_distance;
}

int main() {
    printf("Robot initialized. Starting movement...\n");

    while (true) {
        int distance = check_obstacle_distance();

    
        if (distance == 0) {
            printf("CRITICAL: Obstacle detected at %d cm! Emergency Stop!\n", distance);
            break;
        }

    
        if (distance <= 30) {
            printf("WARNING: Obstacle ahead (%d cm). Slowing down...\n", distance);
            continue; 
        }

        
        printf("Path clear (%d cm). Moving forward at full speed.\n", distance);
    }

    printf("Robot safely stopped. System standby.\n");
    return 0;
}
