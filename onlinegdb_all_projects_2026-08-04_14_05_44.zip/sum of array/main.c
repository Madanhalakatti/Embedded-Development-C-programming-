/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a1[3] ={4,7,9};
    int a2[4] = {7,1,8,93};
    int sum1 =0, sum2=0, total = 0;
    int i;
    for (i=0; i<3; i++)
    {
        sum1 = sum1 + a1[i];
    }
    for (i=0; i<4; i++)
    {
        sum2 = sum2+ a2[i];
        
    }
total = sum1 + sum2;
printf("sum of first array= %d\n", sum1);
printf("sum of second array= %d\n", sum2);
printf("total sum = %d\n", total);
return 0;
}