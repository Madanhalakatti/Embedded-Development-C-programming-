/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a1[3] ={2,4,6};
    int a2[4] = {7,1,8,93};
    int prod1 =1, prod2=1, total = 1;
    int i;
    for (i=0; i<3; i++)
    {
        prod1 = prod1 * a1[i];
    }
    for (i=0; i<4; i++)
    {
        prod2 = prod2 * a2[i];
        
    }
total = prod1 * prod2;
printf("prod of first array= %d\n", prod1);
printf("prod of second array= %d\n", prod2);
printf("total prod = %d\n", total);
return 0;
}