/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num = 10;
    int *ptr;
    int **pptr;

    ptr = &num;
    pptr = &ptr;

    printf("Value of variable           = %d\n", num);
    printf("Address of variable         = %p\n", &num);

    printf("Value of pointer            = %p\n", ptr);
    printf("Address of pointer          = %p\n", &ptr);

    printf("Value of pointer to pointer = %p\n", pptr);

    return 0;
}