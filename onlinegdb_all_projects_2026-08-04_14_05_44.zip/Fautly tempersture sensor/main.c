/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int temps[] = {30, 32, -999, 35, 40};
    int size = sizeof(temps) / sizeof(temps[0]);
    int sum = 0;
    int count = 0;

    for (int i = 0; i < size; i++) {
    
        if (temps[i] == -999) {
            continue;
        }


        sum += temps[i];
        count++;
        
        printf("Processed valid temperature: %d\n", temps[i]);
    }


    if (count > 0) {
        float average = (float)sum / count;
        printf("Total sum: %d\n", sum);
        printf("Average temperature: %.2f\n", average);
    }

    return 0;
}