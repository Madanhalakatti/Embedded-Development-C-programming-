/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void alarm(int temperature);

int main()
{
    int temperature;

    printf("Enter Temperature: ");
    scanf("%d", &temperature);

    alarm(temperature);

    return 0;
}

void alarm(int temperature)
{
    if (temperature > 50)
    {
        printf("Buzzer ON\n");
    }
    else
    {
        printf("Buzzer OFF\n");
    }
}