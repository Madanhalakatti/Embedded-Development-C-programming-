/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Book
{
    int id;
    char name[30];
    float price;
};

int main()
{
    struct Book b;

    printf("Enter Book ID");
    scanf("%d", &b.id);

    printf("Enter Book Name");
    scanf("%s", b.name);

    printf("Enter Book Price");
    scanf("%f", &b.price);

    printf("Book ID = %d\n", b.id);
    printf("Book Name = %s\n", b.name);
    printf("Book Price = %.2f\n", b.price);

    return 0;
}