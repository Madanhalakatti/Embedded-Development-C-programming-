/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> 

int main() {
    int choice;

    srand(time(NULL));

    start_initialization:

    printf("========================================\n");
    printf("Display: Machine Initializing...\n");
    printf("========================================\n");
    

    sleep(2); 


    int init_status = rand() % 2; 

    if (init_status == 1) {
        printf("ERROR: Initialization Failed!\n");
        printf("Restarting system automatically...\n\n");
        sleep(1);

        goto start_initialization;
    }

    printf("SUCCESS: Machine Initialized successfully!\n");
    printf("System is now ready for use.\n");

    return 0;
}
