/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct Student
{
    int rollno;
    float marks;
};

int main()
{
    struct Student s1;
    struct Student *ptr;
    ptr = &s1;

    ptr->rollno= 100;
    ptr-> marks= 95.7;
    printf("Roll no=%d\n",ptr->rollno);
    printf("Marks=%.2f\n", ptr->marks);

    return 0;
}
