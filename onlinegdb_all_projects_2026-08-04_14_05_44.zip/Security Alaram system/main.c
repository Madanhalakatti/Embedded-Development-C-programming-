/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int a = -1, b = 20;

   
    if (a > -1 || b > 20)
    {
        printf("If either door is open  0\n");
    }
    else
    {
        printf("window door is open 0\n");
    }
     if (a < -1 || b < 20)
    {
        printf("If window is open  0\n");
    }
    else
    {
        printf("either door is open 0\n");
    }
    return 0;
}
