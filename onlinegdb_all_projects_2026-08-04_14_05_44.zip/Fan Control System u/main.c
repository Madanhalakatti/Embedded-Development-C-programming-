/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

static int fanStatus = 0;

void turnOn()  { fanStatus = 1; }
void turnOff() { fanStatus = 0; }

int main()
{
    turnOn();
    printf("Fan ON\n");

    turnOff();
    printf("Fan OFF\n");

    return 0;
}
