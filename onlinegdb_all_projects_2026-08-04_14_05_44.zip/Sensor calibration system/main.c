/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>

bool perform_calibration() {
    int result;
    printf("Performing calibration... Enter 1 for SUCCESS or 0 for FAILURE: ");
    scanf("%d", &result);
    return (result == 1);
}

int main() {
    printf("Starting system initialization...\n");

calibration_start: 

    if (!perform_calibration()) {
        printf("Calibration failed! Retrying...\n\n");
        goto calibration_start; 
    }

    printf("Calibration successful! Proceeding to main operations.\n");
    return 0;
}