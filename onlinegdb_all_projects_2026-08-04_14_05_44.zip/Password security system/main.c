/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int password = 1234; 
    int input;           
    int attempts = 0;    


    while (attempts < 5) {
        printf("Enter your 4-digit password: ");
        scanf("%d", &input);
        
        attempts++; 

        if (input == password) {
            printf("Access Granted.\n");
            break;
        } else {
        
            if (attempts < 5) {
                printf("Incorrect password. Attempts remaining: %d\n\n", 5 - attempts);
            }
        }
    }
    if (attempts == 5 && input != password) {
        printf("Access Denied. You have exceeded 5 attempts.\n");
    }

    return 0;
}