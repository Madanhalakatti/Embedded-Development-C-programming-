/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float temp[8];
    int i;
    printf("Enter temperature readings for 8 hours \n");
    for(i = 0; i < 8; i++)
    {
        printf("Hour %d", i + 1);
        scanf("%f", &temp[i]);
    }
    printf("Temperature readings\n");
    for(i = 0; i < 8; i++)
    {
        printf("Hour %d = %.2f\n", i + 1, temp[i]);
    }

    return 0;
}