/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void swap(int a, int b);

int main() {
    int num1, num2;
    printf("Enter first number: ");
    scanf("%d", &num1);
    
    printf("Enter second number: ");
    scanf("%d", &num2);

    
    swap(num1, num2);
    printf("num1 = %d, num2 = %d\n", num1, num2);

    return 0;
}
void swap(int a, int b) {
    int temp;
    temp = a;
    a = b;
    b = temp;

    printf("a= %d, b= %d\n", a, b);
}