/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
int main()
{
    int *ptr;
    int i;
    ptr = (int *)calloc(10,sizeof(int));
    printf("elements are \n");
    for (i=0; i<10; i++)
    {
        printf("%d", ptr[i]);
    }
    free(ptr);
    return 0;
}
