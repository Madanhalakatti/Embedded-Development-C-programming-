/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>

int main() {
    
    bool machine_error = true; 
    int iteration = 1;

    printf("Starting machine operation...\n\n");
    resume_operation:

    while (iteration <= 3) {
        printf("Running cycle %d...\n", iteration);

        
        if (machine_error) {
            printf("[WARNING] Machine error detected!\n");
            
            goto recovery_section;
        }

        iteration++;
    }

    printf("\nMachine operation completed successfully.\n");
    return 0;

    
    recovery_section:
    
    printf("[RECOVERY] Executing error recovery protocols...\n");
    printf("[RECOVERY] Resetting sensors and clearing errors...\n");
    

    machine_error = false; 
    
    printf("[RECOVERY] Recovery complete. Resuming operation...\n\n");
    

    goto resume_operation;
}
