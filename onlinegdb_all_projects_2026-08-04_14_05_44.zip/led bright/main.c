/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void setBrightness(int brightness)
{
    printf("Brightness inside function before change = %d\n", brightness);

    brightness = 100;  

    printf("Brightness inside function after change = %d\n", brightness);
}

int main()
{
    int brightness = 50;

    printf("Brightness before function call = %d\n", brightness);

    setBrightness(brightness);

    printf("Brightness after function call = %d\n", brightness);

    return 0;
}