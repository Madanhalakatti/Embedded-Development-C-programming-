/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void calibrate_adc(int adc_value)
{
    adc_value = adc_value + 10;  

    printf("ADC value inside function = %d\n", adc_value);
}

int main()
{
    int adc_value = 100;

    printf("Original ADC value before function call = %d\n", adc_value);


    return 0;
}