/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void streetLight(int ldrValue);

int main()
{
    int ldrValue;

    printf("Enter LDR Value: ");
    scanf("%d", &ldrValue);

    streetLight(ldrValue);

    return 0;
}
void streetLight(int ldrValue)
{
    int threshold = 30;

    if (ldrValue < threshold)
    {
        printf("Street Light ON\n");
    }
    else
    {
        printf("Street Light OFF\n");
    }
}