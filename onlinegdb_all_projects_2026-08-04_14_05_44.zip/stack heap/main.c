/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/#include <stdio.h>
#include <stdio.h>
#include<stdlib.h>

int main()
{
    int localVar = 10;      // Stored in Stack
    int *ptr;               // Pointer variable

    ptr = (int *)malloc(sizeof(int));   // Allocate memory in Heap

    *ptr = 20;

    printf("Local Variable = %d\n", localVar);
    printf("Address of Local Variable (Stack) = %p\n", (void *)&localVar);

    printf("Dynamic Variable = %d\n", *ptr);
    printf("Address of Dynamic Variable (Heap) = %p\n", (void *)ptr);

    free(ptr);   // Free heap memory

    return 0;
}