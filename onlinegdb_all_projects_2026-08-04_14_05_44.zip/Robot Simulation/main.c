/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int step;

    printf("Starting forward 10 steps...\n");

    for(step = 1; step <= 10; step++) {
        printf("Step %d\n", step);
    }

    printf("Finished all 10 steps.\n");
    
    return 0;
}
