/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>

void moveElevator(int current, int target) {
    if (current == target) {
        printf("\n🚪 You are already on the %d floor!\n", current);
        return;
    }

    printf("\n⬆️  Moving elevator... \n");

    
    if (current < target) {
        for (int i = current + 1; i <= target; i++) {
            printf("Ding! Arrived at floor %d\n", i);
            sleep(1); 
        }
    } 

    else {
        for (int i = current - 1; i >= target; i--) {
            printf("Ding! Arrived at floor %d\n", i);
            sleep(1); 
        }
    }
    
    printf("🚪 Door opening at floor %d. Arrived!\n\n", target);
}

int main() {
    int currentFloor, targetFloor;

    printf("=== ELEVATOR SYSTEM ===\n");
    printf("1. Ground Floor\n");
    printf("2. First Floor\n");
    printf("3. Second Floor\n");
    printf("4. Third Floor\n");
    printf("=======================\n");
    printf("Enter your current floor (1-4): ");
    scanf("%d", &currentFloor);

    if (currentFloor < 1 || currentFloor > 4) {
        printf("❌ Invalid floor! Please restart and select between 1 and 4.\n");
        return 1;
    }

    printf("Select the destination floor (1-4): ");
    scanf("%d", &targetFloor);

    if (targetFloor < 1 || targetFloor > 4) {
        printf("❌ Invalid floor! Please restart and select between 1 and 4.\n");
        return 1;
    }

    moveElevator(currentFloor, targetFloor);

    return 0;
}
