/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void pulse_counter(int *count)
{
    static int pulses = 0;  

    pulses++;
    *count = pulses;        
}

int main()
{
    int pulse_count;

    pulse_counter(&pulse_count);
    printf("Pulse Count = %d\n", pulse_count);

    pulse_counter(&pulse_count);
    printf("Pulse Count = %d\n", pulse_count);

    pulse_counter(&pulse_count);
    printf("Pulse Count = %d\n", pulse_count);

    return 0;
}