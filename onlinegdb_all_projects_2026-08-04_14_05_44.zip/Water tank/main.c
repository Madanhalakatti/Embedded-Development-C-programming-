/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int l =95; int c = 100;
    if(l<c)
    printf("water tank is empty t\n");
    else
    printf("water tank is full t\n");
    return 0;
    if(l>c)
    printf("water tank is full t\n");
    else
    printf("water tank is empty t\n");
    return 0;
}

    
