/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void UART_SendChar(char data);

int main()
{
    UART_SendChar('A');
    UART_SendChar('B');
    UART_SendChar('C');

    return 0;
}
void UART_SendChar(char data)
{
    printf("sending:%c\n", data);
}
