/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

float powerConsumption(float voltage, float current)
{
    return voltage * current;
}

int main()
{
    float voltage, current;

    printf("Enter voltage and current: ");
    scanf("%f %f", &voltage, &current);

    printf("Power = %2f W", powerConsumption(voltage, current));

    return 0;
}