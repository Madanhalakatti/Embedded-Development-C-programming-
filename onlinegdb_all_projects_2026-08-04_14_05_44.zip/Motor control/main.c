/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int speed= 1000; 
    (speed > 1000) ? printf("Motor off\n") : printf("motor on\n");
    (speed < 1000 ) ? printf("Motor on\n"):printf("motor off\n");

    return 0;
}


