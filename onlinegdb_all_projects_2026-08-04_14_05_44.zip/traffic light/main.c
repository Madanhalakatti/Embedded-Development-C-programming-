/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

void Red_LED()
{
    printf("RED Signal - STOP\n");
}

void Yellow_LED()
{
    printf("YELLOW Signal - GET READY\n");
}

void Green_LED()
{
    printf("GREEN Signal - GO\n");
}

int main()
{
    Red_LED();
    Yellow_LED();
    Green_LED();

    return 0;
}