/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[4] = {1, 2, 3, 5};
    int n = 5;
    int sum = 0, expected, i;

    for(i = 0; i < 4; i++)
    {
        sum += a[i];
    }

    expected = n * (n + 1) / 2;

    printf("Missing number = %d\n", expected - sum);

    return 0;
}