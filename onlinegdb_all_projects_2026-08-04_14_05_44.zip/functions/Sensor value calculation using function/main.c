/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int averageSensor(int s1, int s2, int s3);

int main()
{
    int s1, s2, s3, avg;

    printf("Enter Sensor 1 Value: ");
    scanf("%d", &s1);

    printf("Enter Sensor 2 Value: ");
    scanf("%d", &s2);

    printf("Enter Sensor 3 Value: ");
    scanf("%d", &s3);

    avg = averageSensor(s1, s2, s3);

    printf("Average Value = %d\n", avg);

    return 0;
}

int averageSensor(int s1, int s2, int s3)
{
    return (s1 + s2 + s3) / 3;
}