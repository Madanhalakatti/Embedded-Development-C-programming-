/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[5] = {10, 20, 30, 40, 50};
    int b[5];
    int i, j;

    for(i = 0, j = 4; i < 5; i++, j--)
    {
        b[i] = a[j];
    }

    printf("Reversed array\n");

    for(i = 0; i < 5; i++)
    {
        printf("%d ", b[i]);
    }

    return 0;
}