/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int checkSensor(int sensorValue, int threshold)
{
    if (sensorValue > threshold)
        return 1; 
    else
        return 0; 
}

int main()
{
    int sensorValue, threshold;

    printf("Enter sensor value ");
    scanf("%d", &sensorValue);

    printf("Enter threshold value ");
    scanf("%d", &threshold);

    if (checkSensor(sensorValue, threshold))
        printf("Status Above Threshold");
    else
        printf("Status Below Threshold");

    return 0;
}