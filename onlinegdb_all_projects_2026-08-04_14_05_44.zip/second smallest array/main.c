/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[5] = {10, 20, 50, 30, 40};
    int i;
    int min = arr[0];
    int second = arr[0];

    for(i = 1; i < 5; i++)
    {
        if(arr[i] < min)
            min = arr[i];
    }

    second = 99999;   

    for(i = 0; i < 5; i++)
    {
        if(arr[i] > min && arr[i] < second)
            second = arr[i];
    }

    printf("Second smallest element = %d\n", second);

    return 0;
}