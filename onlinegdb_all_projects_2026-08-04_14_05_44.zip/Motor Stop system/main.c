/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int emergency_switch = 0; 
    int time_step = 1;
    while (1) {
        printf("Motor is running... (Time step: %d)\n", time_step);
        if (time_step == 3) {
            emergency_switch = 1;
        }

        if (emergency_switch == 1) {
            printf("EMERGENCY: Switch is ON! Stopping motor immediately.\n");
            break;
        }

        time_step++;
    }

    printf("Motor is now fully stopped.\n");
    return 0;
}