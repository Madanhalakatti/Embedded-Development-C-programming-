/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void Add(int a, int b);
void Sub(int a, int b);
void Mul(int a, int b);
void Div(int a, int b);

int main()
{
    int a, b, choice;

    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    printf("\n1. Add");
    printf("\n2. Subtract");
    printf("\n3. Multiply");
    printf("\n4. Divide");
    printf("\nEnter your choice: ");
    scanf("%d", &choice);

    switch(choice)
    {
        case 1:
            Add(a, b);
            break;

        case 2:
            Sub(a, b);
            break;

        case 3:
            Mul(a, b);
            break;

        case 4:
            Div(a, b);
            break;

        default:
            printf("Invalid Choice\n");
    }

    return 0;
}

void Add(int a, int b)
{
    printf("Sum = %d\n", a + b);
}

void Sub(int a, int b)
{
    printf("Difference = %d\n", a - b);
}

void Mul(int a, int b)
{
    printf("Product = %d\n", a * b);
}

void Div(int a, int b)
{
    if (b != 0)
        printf("Quotient = %d\n", a / b);
    else
        printf("Division by zero is not allowed\n");
}