/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void increase_speed(int *speed)
{
    *speed = *speed + 10; 
}

int main()
{
    int speed = 0;

    printf("Initial Speed = %d\n", speed);

    increase_speed(&speed);
    printf("After 1st Call = %d\n", speed);

    increase_speed(&speed);
    printf("After 2nd Call = %d\n", speed);

    increase_speed(&speed);
    printf("After 3rd Call = %d\n", speed);

    return 0;
}