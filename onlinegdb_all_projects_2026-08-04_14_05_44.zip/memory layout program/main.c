/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int globalVar = 10;          // Global variable
static int staticGlobal = 20; // Static global variable

int main()
{
    int localVar = 30;             // Local variable
    static int staticLocal = 40;   // Static local variable
    int *dynamicVar;               // Pointer for dynamic memory

    dynamicVar = (int *)malloc(sizeof(int));

    *dynamicVar = 50;

    printf("Global Variable:\n");
    printf("Value = %d, Address = %p\n\n", globalVar, (void *)&globalVar);

    printf("Static Global Variable:\n");
    printf("Value = %d, Address = %p\n\n", staticGlobal, (void *)&staticGlobal);

    printf("Local Variable:\n");
    printf("Value = %d, Address = %p\n\n", localVar, (void *)&localVar);

    printf("Static Local Variable:\n");
    printf("Value = %d, Address = %p\n\n", staticLocal, (void *)&staticLocal);

    printf("Dynamic Variable:\n");
   printf("Value = %d, Address = %p\n\n", *dynamicVar, (void *)dynamicVar);

    free(dynamicVar);

    return 0;
}