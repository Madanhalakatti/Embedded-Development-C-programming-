/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

typedef struct
{
    int book_id;
    char book_name[30];
    float price;
} LibraryBook;

void display(LibraryBook b[], int n)
{
    int i;

    printf(" Book Records \n");

    for(i = 0; i < n; i++)
    {
        printf("Book ID = %d\n", b[i].book_id);
        printf("Book Name = %s\n", b[i].book_name);
        printf("Price = %.2f\n", b[i].price);
        printf("\n");
    }
}

int main()
{
    LibraryBook book[3];
    int i;

    for(i = 0; i < 3; i++)
    {
        printf("Enter Book ID, Book Name and Price for Book %d:\n", i + 1);
        scanf("%d %s %f",
              &book[i].book_id,
              book[i].book_name,
              &book[i].price);
    }

    display(book, 3);

    return 0;
}