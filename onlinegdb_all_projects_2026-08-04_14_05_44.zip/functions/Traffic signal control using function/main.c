/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void Red_LED();
void Yellow_LED();
void Green_LED();

int main()
{
    printf("Traffic Signal Simulation\n");

    Red_LED();
    Yellow_LED();
    Green_LED();

    return 0;
}
void Red_LED()
{
    printf("RED LED ON - STOP\n");
}

void Yellow_LED()
{
    printf("YELLOW LED ON - WAIT\n");
}

void Green_LED()
{
    printf("GREEN LED ON - GO\n");
}