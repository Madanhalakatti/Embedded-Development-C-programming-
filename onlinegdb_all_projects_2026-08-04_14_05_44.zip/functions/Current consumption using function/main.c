/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
float currentConsumption(float voltage, float current);

int main()
{
    float voltage, current, power;

    printf("Enter Voltage (V): ");
    scanf("%f", &voltage);

    printf("Enter Current (A): ");
    scanf("%f", &current);

    power = currentConsumption(voltage, current);

    printf("Power Consumed = %.2f Watts\n", power);

    return 0;
}
float currentConsumption(float voltage, float current)
{
    return voltage * current;
}