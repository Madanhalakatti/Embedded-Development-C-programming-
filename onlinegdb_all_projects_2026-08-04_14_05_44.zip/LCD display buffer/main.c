/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char lcd[2][16] = {
        "Hello World",
        "Embedded C"
    };

    int i;

    printf("LCD Display:\n");

    for(i = 0; i < 2; i++)
    {
        printf("%s\n", lcd[i]);
    }

    return 0;
}