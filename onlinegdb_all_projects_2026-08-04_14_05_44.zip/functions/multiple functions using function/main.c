/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void Sensor_Read();
void Store_Data();
void Display_Data();

int main()
{
    printf("Execution Flow:\n");
    Sensor_Read();
    Store_Data();
    Display_Data();

    return 0;
}

void Sensor_Read()
{
    printf("1. Sensor Data Read\n");
}

void Store_Data()
{
    printf("2. Sensor Data Stored\n");
}

void Display_Data()
{
    printf("3. Sensor Data Displayed\n");
}
