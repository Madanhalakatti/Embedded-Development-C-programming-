/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <unistd.h> 


void blinkLED() {
    printf("[LED ON]  * \n");
    usleep(500000);
    printf("[LED OFF] _ \n");
    usleep(500000); 
}

int main() {
    int blinkCount = 1; 

    printf("Starting LED blink program (1 to 10):\n\n");

    while (blinkCount <= 10) {
        printf("Blink Number: %d\n", blinkCount);
        
        blinkLED(); 
        
        blinkCount++; 
        printf("---------------------\n");
    }

    printf("Program finished. LED blinked 10 times.\n");
    return 0;
}