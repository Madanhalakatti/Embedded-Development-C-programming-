/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void display()
{
    auto int num = 10;
    printf("Inside function: %d\n", num);
}

int main()
{
    display();

    // Trying to access num outside its function
    printf("Inside main: %d\n", num);

    return 0;
}