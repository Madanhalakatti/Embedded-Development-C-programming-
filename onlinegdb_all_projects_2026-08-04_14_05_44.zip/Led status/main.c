/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int led[5] = {1, 0, 1, 1, 0};

    printf("LED Status: ");

    for(int i = 0; i < 5; i++)
    {
        printf("%d", led[i]);
    }

    return 0;
}
