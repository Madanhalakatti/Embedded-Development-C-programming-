/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void ledControl(int adc)
{
    if (adc < 300)
        printf("Green LED ON");
    else if (adc < 700)
        printf("Yellow LED ON");
    else
        printf("Red LED ON");
}

int main()
{
    int adc;

    printf("Enter ADC value: ");
    scanf("%d", &adc);

    ledControl(adc);

    re