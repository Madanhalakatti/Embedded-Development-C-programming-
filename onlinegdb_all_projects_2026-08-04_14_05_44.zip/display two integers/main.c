/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a = 10, b = 20;
    int *ptr1, *ptr2;

    ptr1 = &a;
    ptr2 = &b;

    printf("Value of a using pointer = %d\n", *ptr1);
    printf("Value of b using pointer = %d\n", *ptr2);

    return 0;
}