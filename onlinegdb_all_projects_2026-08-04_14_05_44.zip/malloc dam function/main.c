/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
int main()
{
    int *ptr;
    int i;
    ptr = (int *)malloc(5*sizeof(int));
    printf("enter 5 numbers\n");
    for(i=0;i<5; i++)
    {
        scanf("%d", &ptr[i]);
    }
    printf("numbers are \n");
    for (i=0; i<5; i++)
    {
        printf("%d", ptr[i]);
    }
    free(ptr);
    return 0;
}
