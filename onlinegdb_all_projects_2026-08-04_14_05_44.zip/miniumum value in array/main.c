/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[10];
    int i, min;

    printf("Enter 10 elements\n");

    for(i = 0; i < 10; i++)
    {
        scanf("%d", &arr[i]);
    }
    min = arr[0];

    for(i = 1; i < 10; i++)
    {
        if(arr[i] <min)
        {
            min = arr[i];
        }
    }

    printf("Minimum value = %d\n", min);

    return 0;
}