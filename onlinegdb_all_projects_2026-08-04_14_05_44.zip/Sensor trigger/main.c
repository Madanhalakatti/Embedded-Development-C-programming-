/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int sensor_triggered = 1;
    int total_events = 0;     
    int simulated_events = 5; 

    printf("--- Sensor Monitoring Started ---\n");

    while (simulated_events > 0) {
        if (sensor_triggered) {
            total_events++; 
            printf("Event %d recorded!\n", total_events);
            simulated_events--; 
        }
    }

    printf("--- Monitoring Complete ---\n");
    printf("Total events recorded: %d\n", total_events);

    return 0;
}
