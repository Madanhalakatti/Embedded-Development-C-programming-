/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int add(int a, int b){
    return a+b;
}
int sub (int a, int b){

   return a-b;
}
int mul (int a , int b){

    return  a*b;
    
}
int div (int a, int b){

    return  a/b;
}
int main(){
    int a, b;
    printf("enter the first number =");
    scanf("%d", &a);
    printf("enter the second number =");
    scanf("%d",&b);
    printf("Add = %d\n", add(a, b));
    printf("sub=%d\n", sub(a, b));
    printf("mul =%d\n", mul(a, b));
    printf("div =%d\n", div(a, b));
    return 0;
}