/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    unsigned char led = 0; 
    printf("Initial state: %d\n", led);
    led ^= 1; 
    printf("After 1st toggle: %d\n", led);
    led ^= 1; 
    printf("After 2nd toggle: %d\n", led);

    return 0;
}