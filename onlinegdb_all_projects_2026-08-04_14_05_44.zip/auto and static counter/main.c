/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void autoCounter()
{
   auto int count = 0;  
    count++;
    printf("Auto Counter = %d\n", count);
}

void staticCounter()
{
    static int count = 0;   
    count++;
    printf("Static Counter = %d\n", count);
}

int main()
{
    int i;

    for(i = 1; i <= 5; i++)
    {
        autoCounter();
        staticCounter();
    }

    return 0;
}