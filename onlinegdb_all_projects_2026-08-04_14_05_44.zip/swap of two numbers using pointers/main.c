/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap (int *a , int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
int main ()
{
    int x = 10 , y = 20;
    printf("Before swap %d %d\n", x, y);
    swap (&x, &y);
    printf("aftrer swap %d %d\n", x, y);
    return 0;
}
    
