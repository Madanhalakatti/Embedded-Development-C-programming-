/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Student
{
    char name[30];
    char usn[20];
    char branch[20];
    float percentage;
};

int main()
{
    struct Student s;

    printf("Enter Student Name: ");
    scanf("%s", s.name);

    printf("Enter USN/Roll Number: ");
    scanf("%s", s.usn);

    printf("Enter Branch: ");
    scanf("%s", s.branch);

    printf("Enter Percentage: ");
    scanf("%f", &s.percentage);
    printf("the student details are\n");
    printf("Name = %s\n", s.name);
    printf("USN/Roll Number = %s\n", s.usn);
    printf("Branch = %s\n", s.branch);
    printf("Percentage = %.2f\n", s.percentage);

    return 0;
}
