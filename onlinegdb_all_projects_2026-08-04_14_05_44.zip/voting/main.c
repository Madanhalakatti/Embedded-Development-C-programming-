/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int  person;
    printf("enter the person");
    scanf("%d", &person);
    if(person<18){
        printf("person is not eligible for voting \n");
    }
    if(person > 60){
        printf("person is  eligible for voting \n");
        printf("person  need for help  \n");
    }
    if(person < 60 && person > 18){
        printf("person is  eligible for voting \n");
        printf("person no need for help  \n");
    }
              return 0;
            }
            

      
    

