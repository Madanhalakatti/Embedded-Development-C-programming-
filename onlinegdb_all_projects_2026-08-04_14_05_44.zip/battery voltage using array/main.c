/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int voltage[5];
    int i;
    printf("Enter 5 battery voltage readings \n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &voltage[i]);
    }
    printf("First reading = %d\n", voltage[0]);
    printf("Last reading = %d\n", voltage[4]);

    return 0;
}
