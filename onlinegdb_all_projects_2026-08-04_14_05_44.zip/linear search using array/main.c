/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[5] = {10, 20, 30, 40, 50};
    int key = 30;
    int i;

    for(i = 0; i < 5; i++)
    {
        if(a[i] == key)
        {
            printf("Element found at index %d\n", i);
            break;
        }
    }

    return 0;
}
