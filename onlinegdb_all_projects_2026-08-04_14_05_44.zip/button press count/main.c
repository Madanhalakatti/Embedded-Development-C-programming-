/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void Presscount()
{
    static int pressCount = 0; 

    pressCount++;

    printf(" Press Count = %d\n", pressCount);
}

int main()
{
    Presscount();
    Presscount();
    Presscount();
    Presscount();

    return 0;
}
