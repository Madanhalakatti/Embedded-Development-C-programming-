/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char ch = 'A';      
    char *ptr;      

    ptr = &ch;          

    printf("Character value: %d\n", ch);
    printf("Address of character: %p\n", (void *)&ch);
    printf("Character using pointer: %c\n", *ptr);

    return 0;
}
