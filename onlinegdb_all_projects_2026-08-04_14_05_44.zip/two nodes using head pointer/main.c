/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Node
{
    int data;
    struct Node *next;
};

int main()
{
    struct Node node1, node2;
    struct Node *head;

    node1.data = 10;
    node2.data = 20;

    node1.next = &node2;
    node2.next = NULL;

    head = &node1;

    printf("First Node Data = %d\n", head->data);
    printf("Second Node Data = %d\n", head->next->data);

    return 0;
}