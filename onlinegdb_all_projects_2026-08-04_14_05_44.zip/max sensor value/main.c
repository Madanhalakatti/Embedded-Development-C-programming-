/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int findmax(int sensor[], int size)
{
    int i, max;

    max = sensor[0];

    for(i = 1; i < size; i++)
    {
        if(sensor[i] > max)
        {
            max = sensor[i];
        }
    }

    return max;
}

int main()
{
    int sensor[5] = {100, 650, 450, 700, 300};
    int maxvalue;

    maxvalue = findmax(sensor, 5);

    printf("Maximum sensor value = %d\n", maxvalue);

    ret