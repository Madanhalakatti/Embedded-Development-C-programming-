/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int batteryPercentage(int adc)
{
    return (adc * 100) / 1023;
}

int main()
{
    int adc;

    printf("Enter ADC value: ");
    scanf("%d", &adc);

    printf("Battery Percentage = %d%%", batteryPercentage(adc));

    return 0;
}
