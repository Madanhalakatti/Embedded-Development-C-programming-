/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i, n, num;
    int positive = 0, negative = 0;
    printf("enter the elements\n");
    scanf("%d", &n);
    for (i= 0; i<n; i++)
    {
        printf("enter number %d", i+1);
        scanf("%d", &num);
        if (num>0)
        positive++;
        else if (num<0)
        negative++;
    }
    printf("positive number =%d\n", positive);
    printf("negative number =%d\n", negative);
    return 0;
    }
