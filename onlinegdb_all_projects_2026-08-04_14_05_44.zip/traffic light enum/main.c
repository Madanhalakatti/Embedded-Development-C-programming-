/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

enum TrafficLight
{
    RED = 1,
    YELLOW,
    GREEN
};

int main()
{
    enum TrafficLight light;

    printf("Enter Traffic Light Value (1-Red, 2-Yellow, 3-Green): ");
    scanf("%d", &light);

    if (light == RED)
        printf("STOP\n");
    else if (light == YELLOW)
        printf("READY\n");
    else if (light == GREEN)
        printf("GO\n");
    else
        printf("Invalid Input\n");

    return 0;
}