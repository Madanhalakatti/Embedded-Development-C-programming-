/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

float average_temp(float temp[], int size)
{
    int i;
    float sum = 0, avg;

    for(i = 0; i < size; i++)
    {
        sum = sum + temp[i];
    }

    avg = sum / size;
    return avg;
}

int main()
{
    float temp[5] = {28.5, 30.0, 29.5, 31.0, 27.5};
    float avg;

    avg = average_temp(temp, 5);

    printf("Average Temperature = %.2f\n", avg);

    return 0;
}