/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Node
{
    int data;
    struct Node *next;
};

int main()
{
    struct Node node1, node2;

    node1.data = 10;
    node2.data = 20;

    node1.next = &node2;   // Connect first node to second
    node2.next = NULL;     // Last node

    printf("First Node Data = %d\n", node1.data);
    printf("Second Node Data = %d\n", node1.next->data);

    return 0;
}