/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Student
{
    int rollno;
    char name[20];
};

int main()
{
    struct Student s[3];
    for( int i = 0; i < 3; i++)
    {
        printf("Enter Roll Number and Name of Student %d\n", i+1);
        scanf("%d %s", &s[i].rollno, s[i].name);
    }

    printf("Student Details\n");

    for(int  i = 0; i < 3; i++)
    {
        printf("Roll No: %d\n", s[i].rollno);
        printf("Name: %s\n", s[i].name);
    }

    return 0;
}