/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int p[3] = {10, 20, 30};
    int * ptr;
    printf("%P\n", p);
    printf ("%p\n", &p[0]);
    printf ("%p \n", &p[1]);
    printf("%p\n", &p[2]);
    return 0;
}