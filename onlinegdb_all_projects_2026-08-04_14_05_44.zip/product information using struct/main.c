/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct Product
{
    int id;
    char name[20];
    float cost;
};

int main()
{
    struct Product p1 = {101, "Laptop", 45000};
    struct Product p2 = {102, "Mouse", 500};

    printf("Product 1 Details\n");
    printf("ID = %d\n", p1.id);
    printf("Name = %s\n", p1.name);
    printf("Cost = %.2f\n", p1.cost);

    printf("product 2 Details\n");
    printf("ID = %d\n", p2.id);
    printf("Name = %s\n", p2.name);
    printf("Cost = %.2f\n", p2.cost);

    return 0;
}