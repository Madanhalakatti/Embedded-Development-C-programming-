/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void waterlevel(int percentage);

int main()
{
    int percentage;

    printf("Enter waterlevel percentage: ");
    scanf("%d", &percentage);

    waterlevel (percentage);
    return 0;
}

void waterlevel(int percentage)
{
    if (percentage >= 90 && percentage <= 100)
    {
        printf("Tank Full\n");
    }
    else if (percentage >= 50 && percentage < 90)
    {
        printf("Tank Half\n");
    }
    else 
    {
        printf("Tank Empty\n");
    }
}
