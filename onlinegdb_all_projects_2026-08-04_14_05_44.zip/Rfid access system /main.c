/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int scanned_cards[10] = {101, 202, 0, 404, 0, 606, 707, 0, 909, 1001};

    printf("Starting RFID card processing...\n");
    printf("----------------------------------\n");

    for (int i = 0; i < 10; i++) {
        int current_card_id = scanned_cards[i];


        if (current_card_id == 0) {
            printf("Card %d: Invalid read or missing card. Skipping...\n", i + 1);
            continue;
        }
        printf("Card %d: Successfully processed Valid Card ID: %d\n", i + 1, current_card_id);
    }

    printf("----------------------------------\n");
    printf("Finished processing all 10 cards.\n");

    return 0;
}
