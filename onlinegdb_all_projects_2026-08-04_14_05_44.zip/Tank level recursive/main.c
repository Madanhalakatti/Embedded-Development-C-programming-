/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void tank_level(int level)
{
    printf("Tank Level = %d\n", level);

    if (level == 1)
        return;

    tank_level(level - 1);
}

int main()
{
    tank_level(5);

    return 0;
}